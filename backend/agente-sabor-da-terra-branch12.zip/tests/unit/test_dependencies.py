
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from unittest.mock import AsyncMock, Mock
from uuid import uuid4

import pytest
from fastapi import HTTPException, status
from google.cloud.storage import Bucket, Client
from sqlalchemy.ext.asyncio import AsyncSession

from api import dependencies
from api.dependencies import (
    get_current_user,
    get_document_service,
    get_document_storage,
)
from api.models.user import User
from api.services.auth import AuthService, InvalidAccessTokenError
from api.storage.base import DocumentStorage
from api.storage.gcs import GCSDocumentStorage
from api.storage.local import LocalDocumentStorage


def test_get_document_storage_selects_local(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setenv("DOCUMENT_STORAGE_BACKEND", "local")
    monkeypatch.setenv("DOCUMENT_STORAGE_DIR", str(tmp_path))
    monkeypatch.delenv("DOCUMENT_STORAGE_BUCKET", raising=False)
    monkeypatch.setattr(dependencies, "_gcs_client", None)
    client_factory = Mock()
    monkeypatch.setattr(dependencies, "Client", client_factory)

    storage = get_document_storage()

    assert isinstance(storage, LocalDocumentStorage)
    assert storage.directory == tmp_path.resolve()
    client_factory.assert_not_called()


def test_get_document_storage_selects_gcs(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("DOCUMENT_STORAGE_BACKEND", "gcs")
    monkeypatch.setenv("DOCUMENT_STORAGE_BUCKET", "documents-bucket")
    monkeypatch.delenv("DOCUMENT_STORAGE_DIR", raising=False)
    monkeypatch.setattr(dependencies, "_gcs_client", None)
    bucket = Mock(spec=Bucket)
    client = Mock(spec=Client)
    client.bucket.return_value = bucket
    client_factory = Mock(return_value=client)
    monkeypatch.setattr(dependencies, "Client", client_factory)

    start = Barrier(2, timeout=5)

    def select_storage() -> DocumentStorage:
        start.wait()
        return get_document_storage()

    with ThreadPoolExecutor(max_workers=2) as executor:
        first = executor.submit(select_storage)
        second = executor.submit(select_storage)
        for future in (first, second):
            storage = future.result(timeout=5)
            assert isinstance(storage, GCSDocumentStorage)
            assert storage.bucket is bucket

    client_factory.assert_called_once_with()
    assert [entry.args for entry in client.bucket.call_args_list] == [
        ("documents-bucket",),
        ("documents-bucket",),
    ]


def test_get_document_service_injects_session_and_storage() -> None:
    session = Mock(spec=AsyncSession)
    storage = Mock(spec=DocumentStorage)

    service = get_document_service(session, storage)

    assert service.repository.session is session
    assert service.storage is storage


@pytest.fixture
def auth_session(
    monkeypatch: pytest.MonkeyPatch,
) -> tuple[AsyncMock, Mock]:
    session = AsyncMock(spec=AsyncSession)
    auth_service = Mock(spec=AuthService)

    monkeypatch.setattr(
        dependencies,
        "_build_auth_service",
        Mock(return_value=auth_service),
    )

    return session, auth_service


@pytest.mark.asyncio
async def test_get_current_user_returns_authenticated_user(
    auth_session: tuple[AsyncMock, Mock],
) -> None:
    user = User(
        id=uuid4(),
        email="employee@example.com",
        password_hash="hash",
    )
    session, auth_service = auth_session
    session, auth_service = auth_session
    auth_service.get_current_user = AsyncMock(return_value=user)

    result = await get_current_user("valid-token", session)

    assert result is user
    auth_service.get_current_user.assert_awaited_once_with("valid-token")
    session.__aexit__.assert_awaited_once()


@pytest.mark.asyncio
async def test_get_current_user_rejects_invalid_token(
    auth_session: tuple[AsyncMock, Mock],
) -> None:
    session, auth_service = auth_session
async def test_get_current_user_rejects_invalid_token(
    auth_session: tuple[AsyncMock, Mock],
) -> None:
    session, auth_service = auth_session
    auth_service.get_current_user = AsyncMock(
        side_effect=InvalidAccessTokenError("invalid token")
    )

    with pytest.raises(HTTPException) as exception:
        await get_current_user("invalid-token", session)

    session.__aexit__.assert_awaited_once()
    assert exception.value.status_code == status.HTTP_401_UNAUTHORIZED
    assert exception.value.detail == "Could not validate credentials."
    assert exception.value.headers == {"WWW-Authenticate": "Bearer"}


@pytest.mark.asyncio
async def test_get_current_user_rejects_missing_user(
    auth_session: tuple[AsyncMock, Mock],
) -> None:
    session, auth_service = auth_session
async def test_get_current_user_rejects_missing_user(
    auth_session: tuple[AsyncMock, Mock],
) -> None:
    session, auth_service = auth_session
    auth_service.get_current_user = AsyncMock(return_value=None)

    with pytest.raises(HTTPException) as exception:
        await get_current_user("valid-token", session)

    session.__aexit__.assert_awaited_once()
    assert exception.value.status_code == status.HTTP_401_UNAUTHORIZED
    assert exception.value.detail == "Could not validate credentials."
    assert exception.value.headers == {"WWW-Authenticate": "Bearer"}

